"""Render build step: publish the prebuilt site in dist/ to build/."""
import shutil
from pathlib import Path

src, out = Path("dist"), Path("build")
if out.exists():
    shutil.rmtree(out)
shutil.copytree(src, out)
print(f"Copied {sum(1 for p in out.rglob('*') if p.is_file())} files to build/")
